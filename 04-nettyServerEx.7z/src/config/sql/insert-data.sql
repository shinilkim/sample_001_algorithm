INSERT INTO "NETTY_EXAMPLE_DB"."USERS" ("USERID", "USERNAME", "PASSWORD") 
VALUES ('foo@foobar.com', 'foobar', 'passWords');
INSERT INTO "NETTY_EXAMPLE_DB"."USERS" ("USERID", "USERNAME", "PASSWORD") 
VALUES ('kris@foobar.com', 'kris jeong', 'zmfltm');
INSERT INTO "NETTY_EXAMPLE_DB"."USERS" ("USERID", "USERNAME", "PASSWORD") 
VALUES ('ace@foobar.com', '���ϵ�', 'numberOne');
INSERT INTO "NETTY_EXAMPLE_DB"."USERS" ("USERID", "USERNAME", "PASSWORD") 
VALUES ('amy@foobar.com', 'amy lim', '');
INSERT INTO "NETTY_EXAMPLE_DB"."USERS" ("USERID", "USERNAME", "PASSWORD") 
VALUES ('emma@foobar.com', '����', 'emma');
