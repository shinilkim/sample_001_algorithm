package util;

import java.io.File;
import java.util.HashSet;
import java.util.Set;

public class FileUtil {
	
	/* 파일 및 디렉토리 목록 */
	public static Set<File> listFiles(File rootDir) {
		Set<File> fileSet = new HashSet<>();
		if( rootDir == null || rootDir.listFiles() == null ) {
			return fileSet;
		}
		
		for (File fileOrDir : rootDir.listFiles()) {
			if( fileOrDir.isFile() ) {
				fileSet.add(fileOrDir);
			} else {
				fileSet.add(fileOrDir);
				fileSet.addAll(listFiles(fileOrDir));
			}
		}
		return fileSet;
	}
	
	public static void printSendDocument() {
		System.out.println(Integer.compare(0, 0));
		System.out.println(Integer.compare(1, 0));
		System.out.println(Integer.compare(0, 10));
	}
	
	public static void main(String [] args) {
		printSendDocument();
		System.exit(0);
		File dir = new File("D:\\mosaicRepository\\kms\\application\\_common\\src\\kmscommon\\files");
		Set<File> list = listFiles(dir);
		for(File file : list) {
			System.out.println((file.isDirectory()?" ==> ":"")+file.getPath()+file.getName());
		}
	}
}
