package sample.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

public class Rambda_02 {
	public static void main(String...strings) {
		t01();
	}
	
	static void t01() {
		Runnable r1 = () -> System.out.println("Hello World!");
		
		Runnable r2 = new Runnable() {
			public void run() {
				System.out.println("Hello World2!");
			}
		};
		
		process(r1);
		process(r2);
		
		process(()-> System.out.println("Hello World3!"));
		
		List<Integer> I = map(
				Arrays.asList("lambdas","in","action"),
				(String s) -> s.length()
				);
		System.out.println(I);
	}
	
	static void process(Runnable r) {
		r.run();
	}
	
	static <T,R> List<R> map(List<T> list, Function<T,R> f) {
		List<R> result = new ArrayList<>();
		for(T s : list) {
			result.add(f.apply(s));
		}
		return result;
	}
}
