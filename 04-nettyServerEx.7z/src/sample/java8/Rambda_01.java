package sample.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class Rambda_01 {
	public static void main(String ... args) {
		//LambdaExam.init();
		//ObjectExam.init();
		Box.init();
	}
}

class Box<E> {
	private E obj;

	public E getObj() {
		return obj;
	}

	public void setObj(E obj) {
		this.obj = obj;
	}
	
	public static void init() {
		Box<String> box = new Box<>();
		box.setObj("shinil.kim");
		System.out.println(box.getObj());
	}
}

class ObjectExam {
	public static void init() {
		Student s1 = new Student().setBirthYear(1978).setName("홍길동").setNumber("1234");
		Student s2 = new Student().setBirthYear(1978).setName("홍길동").setNumber("1234");
		System.out.println(s1.equals(s2));
		

	}
	
	static class Student {
		String name;
		@Override
		public String toString() {
			return "Student [name=" + name + ", number=" + number + ", birthYear=" + birthYear + "]";
		}
		String number;
		int birthYear;
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + birthYear;
			result = prime * result + ((name == null) ? 0 : name.hashCode());
			result = prime * result + ((number == null) ? 0 : number.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Student other = (Student) obj;
			if (birthYear != other.birthYear)
				return false;
			if (name == null) {
				if (other.name != null)
					return false;
			} else if (!name.equals(other.name))
				return false;
			if (number == null) {
				if (other.number != null)
					return false;
			} else if (!number.equals(other.number))
				return false;
			return true;
		}
		public Student() {}
		public Student setName(String name) {
			this.name = name;
			return this;
		}
		public Student setNumber(String number) {
			this.number = number;
			return this;
		}
		public Student setBirthYear(int birthYear) {
			this.birthYear = birthYear;
			return this;
		}
	}
}

class LambdaExam {
	public static void init() {
		t03();
	}
	
	public static void t01() {
		new Thread(new Runnable() {
			@Override public void run() {
				for(int i=0; i<2; i++) {
					System.out.println(i+" hello");
				}
			}
		}).start();
		
		new Thread(()-> {
			for(int i=0; i<2; i++) {
				System.out.println(i+" hello");
			}
		}).start();
	}
	
	public static void t02() {
		exex((i,j)->{
			return i-j;
		});
	}
	public static void exex(Compare compare) {
		int k = 10;
		int m = 20;
		int value = compare.compareTo(k, m);
		System.out.println(value);
	}
	
	public static void t03() {
		List<Car> cars = new ArrayList<>();
		cars.addAll(Arrays.asList(
				new Car("Car1", 1, 1000, 10),
				new Car("Car2", 2, 2000, 20),
				new Car("Car3", 4, 4000, 40),
				new Car("Car4", 6, 1000, 60)
				));
		
		List<Car> list = filter(cars, (Car car)->car.capacity > 4 && car.price < 2500);
		System.out.println(list);
	}
	public static <T> List<T> filter(List<T> list, Predicate<T> p) {
		List<T> result = new ArrayList<>();
		for(T item:list) {
			if(p.test(item)) {
				result.add(item);
			}
		}
		return result;
	}
}

@FunctionalInterface
interface Compare {
	public int compareTo(int value1, int value2);
}

class Car {
	public String name;
	public int capacity;
	public int price;
	public int age;
	public Car(String name, int capacity, int price, int age) {
		this.name = name;this.capacity=capacity;this.price=price;this.age=age;
	}
	@Override public String toString() {
		return "{name:"+name+", capacity:"+capacity+", price:"+price+", age:"+age+"}";
	}
}

interface CheckCar {
	public boolean test(Car car);
}

class CheckCarForBigAndNotExpensive implements CheckCar {
	@Override
	public boolean test(Car car) {
		return car.capacity > 4 && car.price < 2500;
	}
}