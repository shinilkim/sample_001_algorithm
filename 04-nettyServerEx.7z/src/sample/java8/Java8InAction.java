package sample.java8;

import java.util.*;
import static java.util.Comparator.comparing;
import java.util.function.Predicate;

public class Java8InAction {
	public static void main(String ... args) {
		FilteringApples.main();
	}
}

class FilteringApples {
	
	public static void main() {
		List<Apple> inventory = new ArrayList<>();
		inventory.addAll(Arrays.asList(
				new Apple(705, "brown"),
				new Apple(80, "green"), 
				new Apple(155, "green"),
				new Apple(120, "red")
			));
		
		List<Apple> greenApples = filterApples(inventory, FilteringApples::isGreenApple);
		System.out.println("greenApples: "+greenApples);
		
		List<Apple> heavyApples = filterApples(inventory, FilteringApples::isHeavyApple);
		System.out.println("heavyApples: "+heavyApples);
		
		List<Apple> greenApples2 = filterApples(inventory, (Apple a) -> "green".equals(a.getColor()));
		System.out.println("greenApples2: "+ greenApples2);
		
		List<Apple> heavyApples2 = filterApples(inventory, (Apple a) -> a.getWeight() > 150 );
		System.out.println("heavyApples2: "+heavyApples2);
		
		List<Apple> weirdApples = filterApples(inventory, (Apple a) -> a.getWeight() < 80 || "brown".equals(a.getColor()));
		System.out.println("weirdApples: "+weirdApples);
		
		List<Apple> greenApples3 = filter(inventory, new AppleColorPredicate());
		System.out.println("greenApples3: "+greenApples3);
		
		List<Apple> weightApples3 = filter(inventory, new AppleWeightPredicate());
		System.out.println("weightApples3: "+weightApples3);
		
		List<Apple> redApples3 = filter(inventory, new ApplePredicate() {
			@Override public boolean test(Apple apple) {
				return "red".equals(apple.getColor());
			}
		});
		System.out.println("redApples3: "+redApples3);
		
		List<Apple> redApples4 = filter2(inventory, (Apple apple) -> "red".equals(apple.getColor()));
		System.out.println("redApples4: "+redApples4);
		
		/* sort */
		inventory.sort(new Comparator<Apple>() {
			@Override public int compare(Apple a1, Apple a2) {
				return a2.getWeight().compareTo(a1.getWeight());
			}
		});
		System.out.println(inventory);
		
		inventory.sort(new AppleComparator());
		System.out.println(inventory);
		
		inventory.sort(comparing(Apple::getWeight));
		System.out.println(inventory);
		
		inventory.sort((Apple a1, Apple a2) -> a2.getWeight().compareTo(a1.getWeight()));
		System.out.println(inventory);
		
		Thread t = new Thread(()->System.out.println("Hello world"));
		t.start();
	}
	
	static class AppleComparator implements Comparator<Apple> {
        public int compare(Apple a1, Apple a2){
            return a1.getWeight().compareTo(a2.getWeight());
        }
    }
	
	public static <T> List<T> filter2(List<T> list, Predicate<T> p) {
		List<T> result = new ArrayList<>();
		for(T item : list) {
			if(p.test(item)) {
				result.add(item);
			}
		}
		return result;
	}
	
    public static List<Apple> filterApples(List<Apple> inventory, Predicate<Apple> p){
        List<Apple> result = new ArrayList<>();
        for(Apple apple : inventory){
            if(p.test(apple)){
                result.add(apple);
            }
        }
        return result;
    }
    
    public static List<Apple> filter(List<Apple> inventory, ApplePredicate p) {
    	List<Apple> result = new ArrayList<>();
    	for(Apple apple : inventory) {
    		if(p.test(apple)) {
    			result.add(apple);
    		}
    	}
    	return result;
    }
	
    public static List<Apple> filterGreenApples(List<Apple> inventory){
        List<Apple> result = new ArrayList<>();
        for (Apple apple: inventory){
            if ("green".equals(apple.getColor())) {
                result.add(apple);
            }
        }
        return result;
    }

    public static List<Apple> filterHeavyApples(List<Apple> inventory){
        List<Apple> result = new ArrayList<>();
        for (Apple apple: inventory){
            if (apple.getWeight() > 150) {
                result.add(apple);
            }
        }
        return result;
    }

    public static boolean isGreenApple(Apple apple) {
        return "green".equals(apple.getColor()); 
    }

    public static boolean isHeavyApple(Apple apple) {
        return apple.getWeight() > 150;
    }
    
    interface ApplePredicate{
    	public boolean test(Apple a);
    }
    
    static class AppleWeightPredicate implements ApplePredicate {
    	public boolean test(Apple apple) {
    		return apple.getWeight() > 150;
    	}
    }
    
    static class AppleColorPredicate implements ApplePredicate {
    	public boolean test(Apple apple) {
    		return "green".equals(apple.getColor());
    	}
    }
    
    static class AppleRedAndHeavyPredicate implements ApplePredicate {
    	public boolean test(Apple apple) {
    		return "red".equals(apple.getColor()) && apple.getWeight() > 150;
    	}
    }
    
	public static class Apple{
        private int weight = 0;
        private String color = "";

        public Apple(int weight, String color){
            this.weight = weight;
            this.color = color;
        }

        public Integer getWeight() {
            return weight;
        }

        public void setWeight(Integer weight) {
            this.weight = weight;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }

        public String toString() {
            return "Apple{" +
                   "color='" + color + '\'' +
                   ", weight=" + weight +
                   '}';
        }
	}
	
	
}