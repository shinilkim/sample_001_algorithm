package server.util;

public class Constans {
	public static final String RESULT_CODE = "resultCode";
	public static final String MESSAGE = "message";
	
	public static final String METHOD_NOT_ALLOWED_405 = "405";
	public static final String NOT_IMPLEMENTED_501 = "501";
	public static final String NOT_FOUND_404 = "404";
	public static final String OK_200 = "200";
	
	public static final String SUCCESS = "success";
	public static final String FAIL = "fail";
}
