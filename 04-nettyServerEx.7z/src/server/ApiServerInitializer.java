package server;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpContentCompressor;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.ssl.SslContext;
import server.core.ApiRequestParser;

public class ApiServerInitializer extends ChannelInitializer<SocketChannel>{
	// 채널 보안을 위한 SSL 컨텍스트 객체를 지정
	private final SslContext sslCtx;
	
	public ApiServerInitializer(SslContext sslCtx) {
		this.sslCtx = sslCtx;
	}
	
	@Override
	public void initChannel(SocketChannel ch) {
		System.out.println("[X-003] ApiServerInitializer.initChannel(SocketChannel ch)");
		// 클라이언트 채널로 수신된 HTTP 데이터를 처리하기 위한 채널 파이프라인 객체를 생성
		ChannelPipeline p = ch.pipeline();
		
		if(sslCtx != null) {
			p.addLast(sslCtx.newHandler(ch.alloc()));
		}
		
		// HTTP 요청을 처리하는 디코더 지정(클라이언트가 전송한 HTTP 프로토콜을 네티의 바이트 버버로 변환)
		p.addLast(new HttpRequestDecoder());
		// HTTP 프로토콜에서 발생하는 메시지 파편화를 처리하는 디코더
		// HTTP 프로토콜을 구성하는 데이터가 나뉘어서 수신되었을 때 데이터를 하나로 합쳐주는 역할을 수행
		// 인자로 입력된 65536은 한꺼번에 처리 가능한 최대 데이터 크기(65kb 이상의 데이터가 하나의 HTTP 요청으로 수신되면 오류)
		p.addLast(new HttpObjectAggregator(65536));
		// 수신된 HTTP 요청의 처리 결과를 클라이언트로 전송할 때 HTTP 프로토콜로 변환해주는 인코더
		p.addLast(new HttpResponseEncoder());
		// HTTP로 송/수신되는 HTTP의 본문을 gzip 압축 알고리즘을 사용하여 압축과 압축 해제를 수행한다.
		// ChannelDuplexHandler 클래스를 상속받아서 인/아웃바운드에서 모두 호출
		p.addLast(new HttpContentCompressor());
		// HTTP 데이터에서 헤더와 데이터 값을 추출하여 토큰발급과 같은 업무 처리를 클래스로 분기하는 컨트롤러 역활 수행.
		p.addLast(new ApiRequestParser());
	}
}
