package server;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

/**
 * 
 * [B01] API Main
 *
 */
public class ApiServerMain {
	public static void main(String... args) {
		AbstractApplicationContext springContext = null;

		try {
			springContext = new AnnotationConfigApplicationContext(ApiServerConfig.class);
			springContext.registerShutdownHook();

			ApiServer server = springContext.getBean(ApiServer.class);
			System.out.println("[X-001] ApiServerMain.main(args)");
			server.start();
		} finally {
			if (springContext != null) {
				springContext.close();
			}
		}
	}
}

/**
 * # lib
 * commons-logging-1.2.jar
 * commons-pool2-2.4.2.jar
 * gson-2.8.5
 * hamcrest-core-1.3.jar
 * hsqldb-2.4.1.jar
 * jedis-2.9.0.jar
 * junit-4.12.jar
 * log4j-api-2.11.1.jar
 * log4j-core-2.11.1.jar
 * mybatis-3.4.2.jar
 * mybatis-spring-1.3.2.jar
 * netty-all-4.1.28.Final.jar
 * spring-aop-4.3.18.RELEASE.jar
 * spring-beans-4.3.18.RELEASE.jar
 * spring-context-4.3.18.RELEASE.jar
 * spring-core-4.3.18.RELEASE.jar
 * spring-expression-4.3.18.RELEASE.jar
 * spring-jdbc-4.3.18.RELEASE.jar
 * spring-tx-4.3.18.RELEASE.jar
 */