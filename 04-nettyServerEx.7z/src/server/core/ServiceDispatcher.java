package server.core;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * 스프링 기반의 API 서비스 클래스로 HTTP 요청의 URL과 HTTP 메서드에
 * 해당하는 API 서비스 클래스를 생성하여 ApiRequest 인터페이스 현태로 돌려준다.
 *
 */
@Component
public class ServiceDispatcher {
	// 01 정석 변수에 스프링 컨텍스트 할당
	private static ApplicationContext springContext;

	// 02 스프링 컨텍스트는 정적 변수에 직접 할당할 수 없기 때문에
	// 메서드에 Autowired 어노테이션을 사용하여 간접적으로 할당
	@Autowired
	public void init(ApplicationContext springContext) {
		ServiceDispatcher.springContext = springContext;
	}

	protected Logger logger = LogManager.getLogger(this.getClass());

	/**
	 * 03 HTTP 요청에서 추출한 값을 가진 맵 객체를 인수로 하여 dispatch 메서드를 선언
	 * @param requestMap
	 * @return
	 */
	public static ApiRequest dispatch(Map<String, String> requestMap) {
		System.out.println("requestMap: "+requestMap.get("REQUEST_METHOD"));
		String serviceUri = requestMap.get("REQUEST_URI");// 04 HTTP 요청의 URI 값을 확인
		String beanName = null;

		// 05 URI 값이 없으면 beanNamedp 기본값으로 notFound를 설정
		if (serviceUri == null) {
			beanName = "notFound";
		}

		// 06 토큰을 처리하는 API 서비스 클래스 중에서 하나를 선택한다.
		String httpMethod = requestMap.get("REQUEST_METHOD");// 07 HTTP 메서드 확인
		if (serviceUri.startsWith("/tokens")) {
			switch (httpMethod) {
			case "POST":
				beanName = "tokenIssue";
				break;
			case "DELETE":
				beanName = "tokenExpier";
				break;
			case "GET":
				beanName = "tokenVerify";
				break;
			default:
				beanName = "notFound";
				break;
			}
		} else if (serviceUri.startsWith("/users")) {// 08 사용자 조회
			beanName = "users";
		} else {
			beanName = "notFound";
		}
		System.out.println("ServiceDispatch.dispatch {httpMethod:"+httpMethod+", beanName:"+beanName+"}");
		
		ApiRequest service = null;
		try {
			// 09 스프링 컨텍스트에서 API 서비스 클래스 객체를 생성
			service = (ApiRequest) springContext.getBean(beanName, requestMap);
		} catch(Exception e) {
			e.printStackTrace();
			// 10 스프링 컨텍스트에서 API 서비스 클래스를 생성하는 중에 오류가 발생하면
			// 기본 API 서비스 클래스를 생성한다.
			service = (ApiRequest) springContext.getBean("notFound", requestMap);
		}
		
		return service;
	}
}
