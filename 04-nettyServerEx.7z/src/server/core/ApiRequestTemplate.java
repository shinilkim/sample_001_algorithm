package server.core;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.JsonObject;

import server.core.exception.RequestParamException;
import server.core.exception.ServiceException;
import server.util.Constans;

public class ApiRequestTemplate implements ApiRequest {
	protected Logger logger;

	/**
	 * API 요청 data
	 */
	protected Map<String, String> reqData;

	/**
	 * API 처리 결과
	 */
	protected JsonObject apiResult;

	/**
	 * HTTP 요청에서 추출한 필드의 이름과 값을 API 서비스 클래스의 생성자로 전달
	 */
	public ApiRequestTemplate(Map<String, String> reqData) {
		this.logger = LogManager.getLogger(this.getClass());
		this.apiResult = new JsonObject();
		this.reqData = reqData;

		logger.info("request data: " + this.reqData);
	}

	@Override
	public void executeService() {
		try {
			// 02 API 서비스 클래스의 인수로 입력된 HTTP 요청 맵의 정합성을 검증
			this.requestParamValidation();
			this.service();
		} catch (RequestParamException e) {
			logger.error(e);
			this.apiResult.addProperty(Constans.RESULT_CODE, Constans.METHOD_NOT_ALLOWED_405);
		} catch (ServiceException e) {
			logger.error(e);
			this.apiResult.addProperty(Constans.RESULT_CODE, Constans.NOT_IMPLEMENTED_501);
		}
	}

	/**
	 * service 메서드에서 할당한 API 처리 결과를 돌려준다.
	 */
	@Override
	public JsonObject getApiResult() {
		return this.apiResult;
	}

	@Override
	public void requestParamValidation() throws RequestParamException {
		if (getClass().getClasses().length == 0) {
			return;
		}
	}

	public final <T extends Enum<T>> T fromValue(Class<T> paramClass, String paramValue) {
		if (paramValue == null || paramClass == null) {
			throw new IllegalArgumentException("There is no value with name'"+paramValue+"' in Enum "+paramClass.getClass().getName());
		}
		
		for(T param : paramClass.getEnumConstants()) {
			if(paramValue.equals(param.toString())) {
				return param;
			}
		}
		
		throw new IllegalArgumentException("There is no value with name'"+paramValue+"' in Enum "+paramClass.getClass().getName());
	}

	@Override
	public void service() throws ServiceException {
		// TODO Auto-generated method stub
		
	}
}
