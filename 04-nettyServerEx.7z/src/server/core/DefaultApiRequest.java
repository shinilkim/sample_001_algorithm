package server.core;

import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import server.util.Constans;

@Service("notFound")
@Scope("prototype")
public class DefaultApiRequest extends ApiRequestTemplate {
	public DefaultApiRequest(Map<String, String> reqData) {
		super(reqData);
	}
	
	@Override
	public void service() {
		this.apiResult.addProperty(Constans.RESULT_CODE, Constans.NOT_FOUND_404);
	}
}
