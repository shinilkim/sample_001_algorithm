package server;

import java.net.InetSocketAddress;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * 
 * [B02] API 서버의 스프링 설정
 *
 */
@Configuration
@ImportResource("classpath:config/spring/hsqlApplicationContext.xml")
/*
ComponentScan 어노테이션은 스프링이 컴포넌트를 검색할 위치를 지정하는데 여기서는
ApiServer 클래스가 위치한 토큰발급 및 사용자 정보조회 클래스가 위치한 패키지를 지정했다.
 */
@ComponentScan("server, server.core, server.service")
/*
API 서버의 설정 프로퍼티 파일인 api-server.properties 의 위치를 지정했다.
 */
@PropertySource("classpath:config/api-server.perperties")
public class ApiServerConfig {
	@Value("${boss.thread.count}")
	private int bossThreadCount;

	@Value("${worker.thread.count}")
	private int workerThreadCount;

	@Value("${tcp.port}")
	private int tcpPort;
	
	@Bean(name = "bossThreadCount")
	public int getBossThreadCount() {
		return bossThreadCount;
	}

	@Bean(name = "workerThreadCount")
	public int getWorkerThreadCount() {
		return workerThreadCount;
	}

	public int getTcpPort() {
		return tcpPort;
	}

	@Bean(name = "tcpSocketAddress")
	public InetSocketAddress tcpPort() {
		return new InetSocketAddress(tcpPort);
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
