package server.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.gson.JsonObject;

import redis.clients.jedis.Jedis;
import server.core.ApiRequestTemplate;
import server.core.JedisHelper;
import server.core.KeyMaker;
import server.core.exception.RequestParamException;
import server.core.exception.ServiceException;
import server.dao.TokenKey;
import server.util.Constans;

@Service("tokenIssue")
@Scope("prototype")
public class TokenIssue extends ApiRequestTemplate {
	// 02 레디스에 접근하기 위한 제디스 헬퍼 클래스
	private static final JedisHelper helper = JedisHelper.getInstance();
	
	@Autowired
	private SqlSession sqlSession;
	
	public TokenIssue(Map<String, String> reqData) {
		super(reqData);
	}
	
	/**
	 * 03 인증 토큰 발급 API의 입력 파라미터를 검증(usrNo, password)
	 */
	@Override
	public void requestParamValidation() throws RequestParamException {
		if(StringUtils.isEmpty(this.reqData.get("userNo"))) {
			throw new RequestParamException("userNo이 없습니다.");
		}
		
		if(StringUtils.isEmpty(this.reqData.get("password"))) {
			throw new RequestParamException("password가 없습니다.");
		}
	}
	
	@Override
	public void service() throws ServiceException{
		Jedis jedis = null;
		try {
			Map<String, Object> result = sqlSession.selectOne("users.userInfoByPassword", this.reqData);
			
			if(result != null ) {
				final long threeHour = 60 * 60 * 3;// 3H
				long issueDate = System.currentTimeMillis() / 1000;
				String email = String.valueOf(result.get("USERID"));
				
				// token create
				JsonObject token = new JsonObject();
				JsonObject data = new JsonObject();
				token.addProperty("issueDate", issueDate);
				token.addProperty("expireDate", issueDate+threeHour);
				token.addProperty("email", email);
				token.addProperty("userNo", this.reqData.get("userNo"));
				
				// token save
				// 04 발급된 토큰을 레디스에 저장하고 조회하고자 KeyMaker 인터페이스를 사용했다.
				KeyMaker tokenKey = new TokenKey(email, issueDate);
				jedis = helper.getConnection();
				// 지정된 시간 이후에 데이터를 자동으로 삭제한다.
				jedis.setex(tokenKey.getKey(), 60*60*3,  token.toString());
				System.out.println(jedis.get(tokenKey.getKey()));
				
				// helper.
				data.addProperty("token", tokenKey.getKey());
				data.addProperty("issueDate", issueDate);
				data.addProperty("expireDate", issueDate+threeHour);
				this.apiResult.addProperty(Constans.RESULT_CODE, Constans.OK_200);
				this.apiResult.addProperty(Constans.MESSAGE, Constans.SUCCESS);
				this.apiResult.add("data", data);
			} else {
				this.apiResult.addProperty(Constans.RESULT_CODE, Constans.NOT_FOUND_404);
			}
		} catch(Exception e) {
			helper.returnResource(jedis);
		}
	}
}
