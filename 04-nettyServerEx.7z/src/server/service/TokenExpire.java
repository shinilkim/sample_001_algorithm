package server.service;

import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.gson.JsonObject;

import redis.clients.jedis.Jedis;
import server.core.ApiRequestTemplate;
import server.core.JedisHelper;
import server.core.exception.RequestParamException;
import server.core.exception.ServiceException;
import server.util.Constans;

/**
 * 
 * 인증 토큰 만료 API
 *
 */
@Service("tokenExpier")
@Scope("prototype")
public class TokenExpire extends ApiRequestTemplate {
	private static final JedisHelper helper = JedisHelper.getInstance();

	public TokenExpire(Map<String, String> reqData) {
		super(reqData);
	}

	@Override
	public void requestParamValidation() throws RequestParamException {
		if (StringUtils.isEmpty(this.reqData.get("token"))) {
			throw new RequestParamException("token이 없습니다.");
		}
	}

	@Override
	public void service() throws ServiceException {
		Jedis jedis = null;
		try {
			// token save
			jedis = helper.getConnection();
			long result = jedis.del(this.reqData.get("token"));
			
			JsonObject data = new JsonObject();
			data.addProperty("token", this.reqData.get("token"));

			// helper.
			this.apiResult.addProperty(Constans.RESULT_CODE, result==1?Constans.OK_200:Constans.NOT_FOUND_404);
			this.apiResult.addProperty(Constans.MESSAGE, result==1?Constans.SUCCESS:Constans.FAIL);
			this.apiResult.add("data", data);
		} catch (Exception e) {
			helper.returnResource(jedis);
		}
	}
}
