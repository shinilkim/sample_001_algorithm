package server.service;

import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.gson.JsonObject;

import server.core.ApiRequestTemplate;
import server.core.exception.RequestParamException;
import server.core.exception.ServiceException;
import server.util.Constans;

// 01 스프링의 Service 어노테이션은 스프링 컨텍스트가 UserInfo 클래스를 생성할 수 있도록 하며
// 문자열로 지정된 users는 스프링 컨텍스트에서 클래스의 객체를 생성할 때 사용할 이름이다.
// 즉 getBean 메서드 호출의 인자로 사용된다.
@Service("users")
// 02 스프링의 Scope 어노테이션은 스프링 컨텍스트가 객체를 생성할 때 싱글톤으로 생성할 것인지 아니면
// 객체를 요청할 때마다 새로 생성할 것인지를 설정한다.
// 여기에 설정된 prototype 값은 요청할 때마다 새로 생성한다는 의미이며 이 어노테이션을 지정하지 않으면 싱글톤으로 생성
@Scope("prototype")
public class UserInfo extends ApiRequestTemplate {
	@Autowired
	private SqlSession sqlSession;// 03 HSQLDB와 Mybatis 스프링 설정을 기초로하여 sqlSession 객체를 생성하여 할당

	// 04 HTTP 요청의 파라미터값을 인수로 하여 사용자 정보 조회 API 클래스가 생성된다.
	public UserInfo(Map<String, String> reqData) {
		super(reqData);
	}

	@Override
	public void requestParamValidation() throws RequestParamException {
		if (StringUtils.isEmpty(this.reqData.get("email"))) {
			throw new RequestParamException("email이 없습니다.");
		} else {
			System.out.println("requestParamValidation() : OK");
		}
	}

	@Override
	public void service() throws ServiceException{
		// 입력 email 사용자의 이메일을 HTTP heder에 입력한다.
        // 출력 resultCode API 처리 결과코드를 돌려준다. API 처리 결과가 정상이면 결과코드는 200이다.
        // 출력 message API 처리 결과 메시지를 돌려준다. API의 처리결과가 정상일 때는 Success 메시지를 돌려주며
        // 나머지 정상이 아닐 때는 오류 메시지를 돌려준다.
        // 출력 userNo 입력된 이메일에 해당하는 사용자의 사용자 번호를 돌려준다.
		 Map<String, Object> result = sqlSession.selectOne("users.userInfoByEmail", this.reqData);
		 System.out.println(result);
		
		if(result!= null) {
			String userNo = String.valueOf(result.get("USERNO"));
			
			// helper.
			this.apiResult.addProperty(Constans.RESULT_CODE, Constans.OK_200);
			this.apiResult.addProperty(Constans.MESSAGE, Constans.SUCCESS);
			JsonObject data = new JsonObject();
			data.addProperty("userNo", userNo);
			this.apiResult.add("data", data);
		} else {
			this.apiResult.addProperty(Constans.RESULT_CODE, Constans.NOT_FOUND_404);
		}
	}
}
