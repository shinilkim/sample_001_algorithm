package test;

import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.IntBuffer;

import org.junit.Test;
import static org.junit.Assert.*;

public class CreateByteBufferTest {
	@Test
	public void createTest() {
		CharBuffer heapBuffer = CharBuffer.allocate(11);// 11개의 char형 데이터를 저장할 수 있는 힙 버퍼생성
		assertEquals(11, heapBuffer.capacity());// heapBuffer의 capacity 속성이 11인지 검사
		assertEquals(false, heapBuffer.isDirect());// heapBuffer가 다이렉트 버퍼인지 검사
		
		ByteBuffer directBuffer = ByteBuffer.allocateDirect(11);// 11개의 byte형 데이터를 저장할 수 있는 다이렉트 버퍼 생성
		assertEquals(11, directBuffer.capacity());
		assertEquals(true, directBuffer.isDirect());
		
		int [] array = {1,2,3,4,5,6,7,8,9,0,0};// 11개의 데이터가 저장된 int 배열
		IntBuffer intHeapBuffer = IntBuffer.wrap(array);// array 배열을 감싸는 int 버퍼생성
		assertEquals(11, intHeapBuffer.capacity());
		assertEquals(false, intHeapBuffer.isDirect());
	}
}
